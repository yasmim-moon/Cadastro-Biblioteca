from django.shortcuts import render
from django.views.generic.list import ListView,CreateView, UpdateView, DeleteView
from .models import Livrob
from .models import  AvaliarLivro
from django.urls import reverse_lazy
# Create your views here.

class Listlivros(ListView):
    model = Livrob
    model = AvaliarLivro


class Createlivros(CreateView):
    model = Livrob
    fields = ['id','titulo', 'editora','autor','categoria', 'descricao']
    model = AvaliarLivro
    fields = ['livro', 'nome', 'email', 'comentario', 'avaliacao', 'criacao', 'atualizacao', 'ativo']
    success_url = reverse_lazy('list_livros')


class Updatelivros(UpdateView):
    model = Livrob
    fields = ['id', 'titulo', 'editora', 'autor', 'categoria', 'descricao']
    model = AvaliarLivro
    fields = ['livro', 'nome', 'email', 'comentario', 'avaliacao', 'criacao', 'atualizacao', 'ativo']
    success_url = reverse_lazy('list_livros')

class Deletelivros(DeleteView):
    model = Livrob
    model = AvaliarLivro
    success_url = reverse_lazy('list_livros')

