from django.urls import path
from .views import Listlivros, Createlivros, Updatelivros, Deletelivros

urlpatterns = [
    path('', Listlivros.as_view(), name = 'list_livros'),
    path('create/', Createlivros.as_view(), name = 'create_livros'),
    path('update/<id:int/>', Updatelivros.as_views(), name = 'update_livros'),
    path('delete/<id:int/>', Deletelivros.as_views(), name = 'delete_livros'),

]
