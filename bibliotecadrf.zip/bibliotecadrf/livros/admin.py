from django.contrib import admin
from .models import Livrob
from .models import AvaliarLivro

admin.site.register(Livrob)
admin.site.register(AvaliarLivro)
